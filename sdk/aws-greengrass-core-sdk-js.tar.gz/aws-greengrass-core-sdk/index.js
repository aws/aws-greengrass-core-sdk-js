/*
 * Copyright 2010-2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 */
exports.GreengrassInterfaceVersion = '1.1';
exports.Lambda = require('./lambda');
exports.IotData = require('./iotdata');
exports.SecretsManager = require('./secretsmanager');
